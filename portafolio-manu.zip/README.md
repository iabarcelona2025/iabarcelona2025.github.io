# Portafolio de Manu

Sitio web HTML + CSS inspirado en estética tipo Cargo Collective.
Alojado en **GitHub Pages**.

## Cómo publicar
1. Sube estos archivos a tu repositorio en GitHub.
2. Ve a Settings → Pages → Source y elige la rama main.
3. Tu web estará disponible en: https://tuusuario.github.io/tu-portafolio

## Dominio personalizado
- Crea el archivo `CNAME` con tu dominio, por ejemplo:
  ```
  manu.com
  ```
- Añade los registros DNS A y CNAME según las IPs de GitHub Pages.
